# -*- coding: utf-8 -*-
"""
Created on Wed Oct 27 15:08:19 2021

@author: shuleliu
"""

class student: #创建描述学生信息的类
    #以下为类的构造函数
    def __init__(self,stu_id,name,gender,date_of_birth,date_enroll,major_id):
        self.stu_id=stu_id #学号
        self.name=name #名字
        self.gender=gender #性别
        self.date_of_birth=date_of_birth #出生日期
        self.date_enroll=date_enroll #入学日期
        self.major_id=major_id #专业编码

#创建对象s1		
s1=student('10132110115','王小明','男','1993-2-18','2013-9-1','21601')

