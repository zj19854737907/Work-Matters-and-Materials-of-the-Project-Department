import sys, random
n = int(sys.argv[1])
for i in range(n):
    print(random.randrange(0,100))
