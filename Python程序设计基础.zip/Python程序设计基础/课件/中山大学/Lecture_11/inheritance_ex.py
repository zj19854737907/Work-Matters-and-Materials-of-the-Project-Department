# -*- coding: utf-8 -*-

class student:
    def __init__(self,name,stu_id):
        #初始化姓名,学号
        self.name=name
        self.stu_id=stu_id
        
    def say_hi(self):
        print("您好!我叫",self.name,",学号是",self.stu_id)
        


g1=grad_stu("张三","15220123")
g1.say_hi()
g1.publish("Acta Materialia",2017)