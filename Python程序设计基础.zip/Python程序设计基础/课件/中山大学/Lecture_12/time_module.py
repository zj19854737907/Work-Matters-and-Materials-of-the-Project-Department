# -*- coding: utf-8 -*-

import time
import numpy as np
import matplotlib.pyplot as plt

def f(n): #定义一个递归函数 
    if n==1:return 1 
    elif n==2: return 2 
    else: return f(n-2)*f(n-1) 
k=int(input("请输入一个数:")) 
t0=time.perf_counter() #初始时间 
f(k) 
t1=time.perf_counter() - t0 #计算运行程序所需时间
print("t = %.6f"%t1," s")

#以下为课堂练习绘图代码，请在做练习的时候取消注释
#其中nlist为储存1到35的列表，timelist为储存运行时间的列表

#plt.plot(nlist,timelist)   #绘制曲线图
#plt.plot(nlist,timelist)   #绘制散点图
#plt.savefig("n-t.png")  #保存图片
#plt.show()