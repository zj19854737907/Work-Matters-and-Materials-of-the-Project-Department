import random 

n=100
#随机生成x轴上100个点
x = [random.uniform(0,100) for i in range(n)] 
for i in range(0,len(x)-1): 
    for j in range(i+1,len(x)): 
        xi=x[i] 
        xj=x[j] 
        xij=abs(xi-xj) #计算距离

