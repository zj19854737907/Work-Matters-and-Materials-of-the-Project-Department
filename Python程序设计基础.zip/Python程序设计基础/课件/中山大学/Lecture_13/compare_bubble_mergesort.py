# -*- coding: utf-8 -*-
"""
Created on Tue May 22 09:57:00 2018

@author: Administrator
"""
import random
import time
import matplotlib.pyplot as plt
import numpy as np


#提示1：请将课程代码中冒泡和归并排序的函数代码拷贝过来粘贴在下方
#你可以把函数中的print语句注释掉





def gen_list(n):  #用于生成0到100之间随机数的函数
    return [random.uniform(0,100) for i in range(n)]

#提示2，从下文的绘图代码可以看到，你需要生成nlist,time_bubble和time_merge三个列表
#首先，在下方完成nlist的代码，nlist包含从100增加到5000（每次增加100个数）的所有整数，即[100,200,300,...,4900,5000]


#然后，在下方初始化time_bubble和time_merge两个空列表



#提示3，在下方完成for循环，遍历nlist这个列表



#提示4,在循环体内部，针对nlist中的每个元素n，首先调用gen_list函数生成包含n个随机数的列表；
#然后分别调用冒泡排序和归并排序的函数，对该列表进行排序，并参考下方的代码分别计算
#冒泡排序和归并排序的时间，将排序时间分别添加到time_bubble和time_merge两个列表中

"""
t0=time.perf_counter() #初始时间 
f(n) 
t1=time.perf_counter() - t0 #计算运行函数f(n)所需时间
"""


#绘图代码
plt.plot(nlist,time_bubble,label="bubble sort") #冒泡排序运行时间
plt.plot(nlist,time_merge,label="merge sort")  #归并排序运行时间
plt.xlabel("n") #设置x轴名称
plt.ylabel("t")
plt.legend() #生成图例
plt.savefig("time-vs-n.png")
plt.show()