# -*- coding: utf-8 -*-
"""
Created on Mon Jun 10 19:58:31 2019

@author: Administrator
"""

import my_math2    #模块文件名为my_math2.py,故模块名为my_math2

print("my_math2.PI=",my_math2.PI)
print("789/456=",my_math2.div(789,456))