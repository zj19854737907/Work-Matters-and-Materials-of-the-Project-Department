# -*- coding: utf-8 -*-

import numpy as np
import math
from scipy.optimize import curve_fit
import matplotlib.pyplot as plt


#用于产生数据点的二次函数
def f(x):
    return 2*x*x + 5.0

#用于拟合数据的一次函数
def linear_func(x,a,b):
    return a*x + b

#用于拟合数据的二次函数
def quadratic_func(x,a,b,c):
    return a*x*x + b*x + c

#产生具有一定随机性的数据点    
xdata = np.arange(0,10,0.5)
ydata = f(xdata) + 10.0*np.random.normal(size=len(xdata))

#线性拟合并画图
popt, pcov = curve_fit(linear_func,xdata,ydata)
ylinear = linear_func(xdata,popt[0],popt[1])

plt.xlabel('x')
plt.ylabel('y')
plt.scatter(xdata,ydata)
plt.plot(xdata,ylinear,color='red',label='linear fit')
plt.legend()
#plt.savefig('linearfit.png',dpi=200)
plt.show()

#非线性拟合并画图
popt, pcov = curve_fit(quadratic_func,xdata,ydata)
yquadratic = quadratic_func(xdata,popt[0],popt[1],popt[2])
plt.xlabel('x')
plt.ylabel('y')
plt.scatter(xdata,ydata)
plt.plot(xdata,yquadratic,'g--',label='nonlinear fit')
plt.legend()
#plt.savefig('nonlinearfit.png',dpi=200)
plt.show()


