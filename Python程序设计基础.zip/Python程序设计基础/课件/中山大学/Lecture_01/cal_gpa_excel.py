

import xlrd
import xlwt
#打开Excel文件读取数据
data = xlrd.open_workbook('score_credit_GPA.xls')
#获取工作表
table0 = data.sheets()[0]    
#获取sheet1整行和整列数据,返回列表
#获取行数和列数
nrows0 = table0.nrows #行数
ncols0 = table0.ncols #列数
#建立空列表
stu_info=[]
sheet1 = []
sheet2 = []
sheet3 = []
#读取数据
for i in range (1,nrows0):
    #读取sheet1的姓名和相关科目的分数
    Name = table0.cell(i,0).value   #姓名
    Calculus_I = str(table0.cell(i,1).value) #语文
    Linear_Algebra = str(table0.cell(i,2).value) #数学
    College_Physics = str(table0.cell(i,3).value) #英语
    General_Chemistry = str(table0.cell(i,4).value)
    Biology = str(table0.cell(i,5).value)
    General_Chemistry_Lab = str(table0.cell(i,6).value)
    Python_Programming = str(table0.cell(i,7).value)
    sheet1.append([Name,Calculus_I,Linear_Algebra,\
                   College_Physics,General_Chemistry,\
                   Biology,General_Chemistry_Lab,Python_Programming])    
#读取sheet2的数据
table1 = data.sheets()[1]
nrows1 = table1.nrows #行数
ncols1 = table1.ncols #列数
#读取科目对应的学分
for i in range(nrows1):
    Class_name = table1.cell(i,0).value
    credit = int(table1.cell(i,1).value)
    sheet2.append([Class_name,credit])
#读取sheet3的数据
table2 = data.sheets()[2]
nrows2 = table2.nrows #行数
ncols2 = table2.ncols #列数
#读取score对应的绩点
for i in range(nrows2):
    GPA = str(table2.cell(i,0).value)
    score = table2.cell(i,1).value
    sheet3.append([GPA,score])
#将sheet1里面读取的科目等级绩点转变为分数绩点
for m in range(1,8):
    for i in range(len(sheet1)):
        for j in range(len(sheet3)):
            if sheet1[i][m] in sheet3[j]:
                sheet1[i][m] = sheet3[j][1] 
#计算一个学生的平均分数绩点
for i in range(len(sheet1)):
    a = float(sheet1[i][1]*sheet2[0][1] + sheet1[i][2]*sheet2[1][1] + \
    sheet1[i][3]*sheet2[2][1] + sheet1[i][4]*sheet2[3][1] + \
    sheet1[i][5]*sheet2[4][1] + sheet1[i][6]*sheet2[5][1] + \
    sheet1[i][7]*sheet2[6][1])
    a = ('%.3f' % (a/20)) #保留三位小数
    #print(a) #验证输出结果
    stu_info.append([sheet1[i][0],a])
#对输出的结果进行由大到小排序
stu_info_sorted = sorted(stu_info,key=lambda x:x[-1],reverse=True)
stu_info_sorted.insert(0,['姓名','平均绩点'])
#创建Excel工作簿文件
workbook = xlwt.Workbook()
#创建工作表
worksheet = workbook.add_sheet("按分数排序")

#写入数据
for i in range(len(stu_info_sorted)):
    for j in range(2):  
        worksheet.write(i,j,stu_info_sorted[i][j])
        
#保存该Excel工作簿到score_sorted.xls
workbook.save('score_sorted.xls')

print('输出excel文件为：score_sorted.xls')

