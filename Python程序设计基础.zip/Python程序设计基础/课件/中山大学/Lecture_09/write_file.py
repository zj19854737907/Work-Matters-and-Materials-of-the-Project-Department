# -*- coding: utf-8 -*-
"""
Created on Sat Apr 14 11:33:09 2018

@author: Administrator
"""

#字典
stu_score={"John": 83,"Jennifer":66,"Amy":89,"Mark": 90,"Ted":93}

#以写入方式打开要写入的文件
g = open('score_output.txt','w')

#循环字典的每个键值
for stu in stu_score.keys():
    #以格式字符串输出每个人的姓名和分数
   #g.write("%s  %d\n"%(stu,stu_score[stu]))  
   print("%s  %d"%(stu,stu_score[stu]),file=g)
g.close()