"""
如需运行此程序,请先安装pyttsx3
安装方式: 开始菜单->Anaconda3->Anaconda Prompt
在命令行输入: pip install pyttsx3
安装完成后重启Spyder

"""

import pyttsx3

engine=pyttsx3.init()

#朗读中文
engine.say("苟利国家生死以，岂因祸福避趋之")
engine.runAndWait()

engine.say("哈哈哈哈哈哈哈")
engine.runAndWait()

#朗读数字
engine.say("2333333")
engine.runAndWait()

engine.say("23333333333333333")
engine.runAndWait()


#朗读英文
engine.say("Better late than never")
engine.runAndWait()

engine.say("Four score and seven years ago our fathers brought  \
forth on this continent a new nation conceived in liberty and dedicated \
to the proposition that all men are created equal")
engine.runAndWait()
