# -*- coding: utf-8 -*-
"""
Created on Sat Apr 14 11:11:34 2018

@author: Administrator
"""

with open('name_score.txt','r') as f:
     #因为文件对象f是可迭代对象
     #所以可以使用以下语句来遍历f中每一行
     for line in f:
         print(line,end=" ")
         
         

