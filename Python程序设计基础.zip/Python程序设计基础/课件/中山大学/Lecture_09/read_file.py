# -*- coding: utf-8 -*-
"""
Created on Sat Apr 14 11:11:34 2018

@author: Administrator
"""

f = open('name_score.txt','r')
line_no=0   #统计行号

while True:
      line_no+=1    #行号计数
      line = f.readline()        #读取一行
      if line: #只要该行内容对应字符串不为空，即为True
         #输出行号和该行的内容,输出时用空格代替换行符
         print(line_no, ":", line,end=" ")       
      else:
         break
     
f.close()         #关闭文件