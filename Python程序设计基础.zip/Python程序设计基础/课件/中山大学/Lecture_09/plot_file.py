import numpy as np
import matplotlib.pyplot as plt


data=np.loadtxt("time_data.txt")

#获取文本中的每一列
t=data[:,0]
x=data[:,1]
y=data[:,2]
z=data[:,3]

#绘图
plt.plot(t,x,label="x")
plt.plot(t,y,label="y")
plt.plot(t,z,label="z")
plt.xlabel("t")
plt.legend()
#plt.savefig("sincos.png",dpi=200)
plt.show()