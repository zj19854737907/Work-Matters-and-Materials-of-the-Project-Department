# -*- coding: utf-8 -*-

import matplotlib.pyplot as plt

x=[i for i in range(0,21)]
y=[0.5*i*i for i in range(0,21)]

plt.plot(x,y)   #画曲线图
plt.scatter(x,y) #画散点图
plt.xlabel("x") #设置x轴名称
plt.ylabel("y") #设置y轴名称
plt.savefig("test.png")  #保存图片
plt.show() #显示图形
