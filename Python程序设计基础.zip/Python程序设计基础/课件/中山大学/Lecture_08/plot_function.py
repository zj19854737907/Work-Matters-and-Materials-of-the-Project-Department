# -*- coding: utf-8 -*-

import numpy as np
import matplotlib.pyplot as plt

x=np.linspace(-5,5,100,endpoint=False)

#余弦函数
y=np.cos(x)
plt.plot(x,y)
plt.show()
#指数函数
y=np.exp(x)
plt.plot(x,y)
plt.show()
#三次函数
y=x*x*x
plt.plot(x,y)
plt.show()